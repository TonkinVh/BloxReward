# MyRBLX - Web (NodeJS / ExpressJS & MySQL)

MyRBLX.com is a website for earning free Robux by completing surveys. It also incorporates features such as user referrals, promo codes, and giveaways.

\**You can add custom admin/roblox group settings by modifying admin_group_details table in the MySQL database*\*

# Screenshots

![8](https://github.com/mnm967/MyRBLXWeb/assets/67553368/b857b9a3-6dcb-46e8-8d11-bb1d99c04d9f)
![7](https://github.com/mnm967/MyRBLXWeb/assets/67553368/5f8b0c56-f77b-40e9-b9b0-8ba86b3ec083)
![6](https://github.com/mnm967/MyRBLXWeb/assets/67553368/3650885b-8b5c-4d4f-b5e4-c14240355e2e)
![5](https://github.com/mnm967/MyRBLXWeb/assets/67553368/885a18df-a89d-45a7-9beb-169e67ddc069)
![4](https://github.com/mnm967/MyRBLXWeb/assets/67553368/a747a105-b905-489a-b0c6-747a97ac033e)
![3](https://github.com/mnm967/MyRBLXWeb/assets/67553368/c8e56ff6-629e-4c61-a532-b83b15433f97)
![2](https://github.com/mnm967/MyRBLXWeb/assets/67553368/8e61a533-d585-4cbd-92c4-e63a14030b61)
![1](https://github.com/mnm967/MyRBLXWeb/assets/67553368/861a5164-0e49-41fa-b063-4d29ac311599)
